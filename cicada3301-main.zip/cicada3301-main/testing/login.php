<?php

session_set_cookie_params([
    'httponly' => true,
    'samesite'  => 'Strict'
]);

session_start();

if (
    isset($_SESSION['authenticated']) &&
    $_SESSION['authenticated'] === true
) {
    header("Location: index.php");
    exit;
}

$db_path = dirname(__DIR__) . '/database.sqlite';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username_input = trim($_POST['username'] ?? '');
    $password_input = $_POST['password'] ?? '';

    if (
        empty($username_input) ||
        empty($password_input)
    ) {

        $error = "Please fill in all fields.";

    } else {

        try {

            $db = new PDO("sqlite:$db_path");

            $db->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            $db->exec(
                "CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    created_at TEXT
                )"
            );

            $stmt = $db->prepare(
                "SELECT *
                 FROM users
                 WHERE username = :user
                 LIMIT 1"
            );

            $stmt->execute([
                ':user' => $username_input
            ]);

            $user = $stmt->fetch(
                PDO::FETCH_ASSOC
            );

            if (
                $user &&
                password_verify(
                    $password_input,
                    $user['password_hash']
                )
            ) {

                session_regenerate_id(true);

                $_SESSION['authenticated'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['login_time'] = time();

                header("Location: index.php");
                exit;

            } else {

                $error =
                    "Invalid username or password.";
            }

        } catch (PDOException $e) {

            $error =
                "Database connectivity failure.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Gateway Portal</title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family:sans-serif; background:#111; color:#fff; padding:20px; display:flex; justify-content:center; align-items:center; height:80vh; margin:0;">

<div style="background:#222; padding:30px; border-radius:12px; max-width:360px; width:100%; border:1px solid #333;">

    <h2 style="color:#00ff00; text-align:center;">
        Secure Gateway
    </h2>

    <?php if (!empty($error)): ?>
        <div style="background:#421111; color:#ff5555; padding:10px; border-radius:6px; margin-bottom:15px; text-align:center;">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST">

        <input
            type="text"
            name="username"
            placeholder="Username"
            required
            style="width:93%; padding:12px; margin-bottom:15px; border-radius:6px; border:1px solid #444; background:#000; color:#fff; text-align:center;">

        <input
            type="password"
            name="password"
            placeholder="Password"
            required
            style="width:93%; padding:12px; margin-bottom:15px; border-radius:6px; border:1px solid #444; background:#000; color:#fff; text-align:center;">

        <button
            type="submit"
            style="width:100%; padding:12px; border-radius:6px; border:none; background:#00ff00; color:#000; font-weight:bold;">
            Authorize Session
        </button>

    </form>

    <p style="text-align:center; margin-top:20px;">

        <a href="signup.php"
           style="color:#00ff00; text-decoration:none;">
            Create a new node account
        </a>

    </p>

</div>

</body>
</html>
