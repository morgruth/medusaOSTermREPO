<?php
session_start();

if (!isset($_SESSION['authenticated'])) {
    header("Location: login.php");
    exit;
}

$db_path = dirname(__DIR__) . '/database.sqlite';

$message = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    try {

        $db = new PDO("sqlite:$db_path");
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $db->prepare(
            "SELECT password_hash
             FROM users
             WHERE username = :username"
        );

        $stmt->execute([
            ':username' => $_SESSION['username']
        ]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (
            !$user ||
            !password_verify(
                $current,
                $user['password_hash']
            )
        ) {

            $error =
                "Current password is incorrect.";

        } elseif ($new !== $confirm) {

            $error =
                "New passwords do not match.";

        } elseif (strlen($new) < 8) {

            $error =
                "Password must be at least 8 characters.";

        } else {

            $newHash = password_hash(
                $new,
                PASSWORD_DEFAULT
            );

            $update = $db->prepare(
                "UPDATE users
                 SET password_hash = :hash
                 WHERE username = :username"
            );

            $update->execute([
                ':hash' => $newHash,
                ':username' => $_SESSION['username']
            ]);

            session_destroy();

            header("Location: login.php");
            exit;
        }

    } catch (PDOException $e) {

        $error =
            "Database error.";
    }
}
?>
