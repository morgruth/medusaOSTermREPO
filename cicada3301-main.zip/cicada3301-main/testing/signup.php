<?php
session_start();
$db_path = dirname(__DIR__) . '/database.sqlite';
$message = ""; $error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_input = trim($_POST['username'] ?? '');
    $password_input = $_POST['password'] ?? '';
    $confirm_input = $_POST['confirm_password'] ?? '';

    if (empty($username_input) || empty($password_input)) {
        $error = "All fields are strictly required.";
    } elseif ($password_input !== $confirm_input) {
        $error = "Passwords do not match.";
    } elseif (strlen($password_input) < 4) {
        $error = "Password must be at least 4 characters long.";
    } else {
        try {
            $db = new PDO("sqlite:$db_path");
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT, created_at TEXT)");

            $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = :user");
            $stmt->execute([':user' => $username_input]);
            if ($stmt->fetchColumn() > 0) {
                $error = "Username is already registered.";
            } else {
                $hash = password_hash($password_input, PASSWORD_BCRYPT);
                $insert = $db->prepare("INSERT INTO users (username, password_hash, created_at) VALUES (:user, :hash, :ts)");
                $insert->execute([':user' => $username_input, ':hash' => $hash, ':ts' => date('Y-m-d H:i:s')]);

                $message = "Account created! Redirecting...";
                header("refresh:2;url=login.php");
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Register Node</title><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="font-family:sans-serif; background:#111; color:#fff; padding:20px; display:flex; justify-content:center; align-items:center; height:90vh; margin:0;">
    <div style="background:#222; padding:30px; border-radius:12px; max-width:360px; width:100%; border: 1px solid #333;">
        <h2 style="color:#00ff00; margin-top:0; text-align:center;">Register Account</h2>
        <?php if(!empty($error)): ?><div style="background:#421111; color:#ff5555; padding:10px; border-radius:6px; margin-bottom:15px; text-align:center;"><?=htmlspecialchars($error)?></div><?php endif; ?>
        <?php if(!empty($message)): ?><div style="background:#114211; color:#55ff55; padding:10px; border-radius:6px; margin-bottom:15px; text-align:center;"><?=htmlspecialchars($message)?></div><?php endif; ?>
        <?php if(empty($message)): ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required style="width:93%; padding:10px; margin-bottom:15px; border-radius:6px; border:1px solid #444; background:#000; color:#fff;">
            <input type="password" name="password" placeholder="Password" required style="width:93%; padding:10px; margin-bottom:15px; border-radius:6px; border:1px solid #444; background:#000; color:#fff;">
            <input type="password" name="confirm_password" placeholder="Confirm Password" required style="width:93%; padding:10px; margin-bottom:20px; border-radius:6px; border:1px solid #444; background:#000; color:#fff;">
            <button type="submit" style="width:100%; padding:12px; border-radius:6px; border:none; background:#00ff00; color:#000; font-weight:bold;">Register</button>
        </form>
        <?php endif; ?>
        <p style="text-align:center; margin-top:20px; font-size:0.9em;"><a href="login.php" style="color:#aaa; text-decoration:none;">Already have an account? Log In</a></p>
    </div>
</body>
</html>
