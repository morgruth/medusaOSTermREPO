<?php
session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header("Location: login.php");
    exit;
}
$db_path = getenv('HOME') . '/database.sqlite';
$key = trim(file_get_contents(getenv('HOME') . '/.auth/key.txt'));

function encrypt_msg($msg, $key) {
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($msg, "AES-256-CBC", $key, 0, $iv);
    return base64_encode($iv . $cipher);
}

function decrypt_msg($data, $key) {
    $raw = base64_decode($data);
    $iv = substr($raw, 0, 16);
    $cipher = substr($raw, 16);
    return openssl_decrypt($cipher, "AES-256-CBC", $key, 0, $iv);
}

try {

    $db = new PDO("sqlite:$db_path");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $db->exec("
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // SEND MESSAGE
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $msg = trim($_POST['message'] ?? '');

        if ($msg !== '' && strlen($msg) <= 500) {

            $encrypted = encrypt_msg($msg, $key);

            $stmt = $db->prepare("
                INSERT INTO messages (username, message)
                VALUES (:username, :message)
            ");

            $stmt->execute([
                ':username' => $_SESSION['username'],
                ':message' => $encrypted
            ]);
        }
    }

    // FETCH MESSAGES
    $stmt = $db->query("
        SELECT * FROM messages
        ORDER BY id DESC
        LIMIT 50
    ");

    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Chat Room</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body style="background:#111;color:#fff;font-family:sans-serif;padding:20px;">

<div style="max-width:600px;margin:auto;">

    <h2 style="color:#00ff00;text-align:center;">Chat Room</h2>

    <p style="text-align:center;">
        Logged in as:
        <b><?= htmlspecialchars($_SESSION['username']) ?></b>
    </p>

    <form method="POST" style="margin-bottom:20px;">
        <input type="text"
               name="message"
               maxlength="500"
               required
               style="width:80%;padding:10px;">

        <button type="submit" style="padding:10px;">
            Send
        </button>
    </form>

    <div style="background:#222;padding:15px;border-radius:10px;">

        <?php foreach ($messages as $m): ?>

            <div style="margin-bottom:10px;border-bottom:1px solid #333;padding-bottom:8px;">

                <b style="color:#00ff00;">
                    <?= htmlspecialchars($m['username']) ?>
                </b>

                <span style="color:#888;font-size:12px;">
                    <?= $m['created_at'] ?>
                </span>

                <div>
                    <?= htmlspecialchars(decrypt_msg($m['message'], $key)) ?>
                </div>

            </div>

        <?php endforeach; ?>

    </div>

    <p style="text-align:center;margin-top:20px;">
        <a href="index.php" style="color:#aaa;">Back</a> |
        <a href="logout.php" style="color:#ff5555;">Logout</a>
    </p>

</div>

</body>
</html>
