<?php
session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

if (
    !isset($_SESSION['authenticated']) ||
    $_SESSION['authenticated'] !== true
) {
    header("Location: login.php");
    exit;
}

if (
    isset($_SESSION['login_time']) &&
    time() - $_SESSION['login_time'] > 3600
) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$db_path = dirname(__DIR__) . '/database.sqlite';

try {
    $db = new PDO("sqlite:$db_path");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $db->exec(
        "CREATE TABLE IF NOT EXISTS visits (
            id INTEGER PRIMARY KEY,
            ts TEXT
        )"
    );

    $stmt = $db->prepare(
        "INSERT INTO visits (ts)
         VALUES (:ts)"
    );

    $stmt->execute([
        ':ts' => date('Y-m-d H:i:s')
    ]);

    $count = $db->query(
        "SELECT COUNT(*) FROM visits"
    )->fetchColumn();

} catch (PDOException $e) {

    die("Database error");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<meta name="viewport"
      content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family:sans-serif;background:#111;color:#fff;padding:20px;text-align:center;">

<div style="background:#222;padding:30px;border-radius:12px;max-width:400px;margin:40px auto;border:2px solid #00ff00;">

<h1 style="color:#00ff00;">
Access Granted
</h1>

<p>
Active Operator:
<strong style="color:#00ff00;">
<?= htmlspecialchars($_SESSION['username']) ?>
</strong>
</p>

<p style="background:#000;padding:15px;border-radius:6px;">
SQLite Engine Views: <?= $count ?>
</p>

<hr>
<p style="text-align:center;margin-top:20px;">
    <a href="index.php" style="color:#00ff00;text-decoration:none;font-weight:bold;">
        Dashboard
    </a>
    <a href="chat_room.php" style="color:#aaa;text-decoration:none;">
        Chat
    </a>
<a href="change_password.php"
   style="color:#00ff00;">
Change Password
</a>
   <a href="logout.php" style="color:#ff5555;text-decoration:none;">
        Logout
    </a>
</p>
<br>
<h1>RULES</h1>
<p>person persons we us them it. all the pronoun game<br>
can only have one account on this site.
use polite language. no buying no selling users that are ar going to be permaband
and will not be allowed on the site ever.
file sharing is not allowed
</p>

</div>

</body>
</html>
